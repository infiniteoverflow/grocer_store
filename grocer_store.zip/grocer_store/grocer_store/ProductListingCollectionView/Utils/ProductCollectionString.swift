//
//  ProductCollectionString.swift
//  grocer_store
//
//  Created by Aswin Gopinathan on 24/02/23.
//

import Foundation

// String used in the Product CollectionView section.
class ProductCollectionString {
    
    // Identifier for the CollectionView Cell.
    static let productCollectionCellIdentifier = "ProductCollectionViewCell"
}
