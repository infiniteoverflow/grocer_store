//
//  AppEnums.swift
//  grocer_store
//
//  Created by Aswin Gopinathan on 25/02/23.
//

import Foundation

enum NetworkState {
    case loading,success,failure
}
