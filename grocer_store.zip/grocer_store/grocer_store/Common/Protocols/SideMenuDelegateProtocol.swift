//
//  SideMenuDelegateProtocol.swift
//  grocer_store
//
//  Created by Aswin Gopinathan on 05/03/23.
//

import Foundation

protocol SideMenuDelegate: AnyObject {
    func menuButtonTapped()
}
